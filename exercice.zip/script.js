// ========================================
// DOM Elements
// ========================================
const postForm = document.getElementById('post-form');
const generateBtn = document.getElementById('generate-btn');
const resultSection = document.getElementById('result-section');
const generatedPost = document.getElementById('generated-post');
const hashtagsSection = document.getElementById('hashtags-section');
const hashtags = document.getElementById('hashtags');
const copyBtn = document.getElementById('copy-btn');
const regenerateBtn = document.getElementById('regenerate-btn');
const saveBtn = document